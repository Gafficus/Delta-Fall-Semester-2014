﻿' Name:         Fairmont Project
' Purpose:      Displays the total sales and total commission
' Programmer:   <your name> on <current date>

Public Class frmMain

End Class
