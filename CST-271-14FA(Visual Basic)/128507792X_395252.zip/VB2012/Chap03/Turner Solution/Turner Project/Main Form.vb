﻿' Name:         Turner Project
' Purpose:      Displays the new hourly pay for each of 3 job codes
' Programmer:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

End Class
