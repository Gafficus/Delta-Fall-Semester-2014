﻿' Name:         Happy Flooring Project
' Purpose:      Displays the area of a floor in square yards
' Programmer:   <your name> on <current date>

Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
