#Created by: Nathan Gaffney
#7-Sep-2014
#Chapter 1 Project 2
print "Nathan Gaffney"
raw_input("\n\nPress enter to exit.")
