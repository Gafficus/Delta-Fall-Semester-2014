#Created by: Nathan Gaffney
#28-Sep-2014
#Chapter 5 Project 1
#THis program will use functions to dosplay a message
def first():
    print "In function first()"
    second()
def second():
    print "\nIn function second()"
first()
