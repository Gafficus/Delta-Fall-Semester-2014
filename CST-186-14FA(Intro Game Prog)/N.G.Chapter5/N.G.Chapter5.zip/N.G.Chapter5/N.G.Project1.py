#Created by: Nathan Gaffney
#21-Sep-2014
#Chapter 5 Project 1
#This program will create a list of user's favorite games.
gameName = []
for i in range(5):
    name1 = raw_input("Enter name of favorite game :")
    gameName.append(name1)
print gameName
raw_input("Press enter to exit.")
